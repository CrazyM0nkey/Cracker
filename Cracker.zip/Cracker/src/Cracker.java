import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/*
 * In der Main-Methode wird zuerst ein Objekt der Klasse Cracker erzeugt, dann wird die 
 * Methode passwortGen1 auf dem Objekt aufgerufen. Beim Aufruf wird ein Salt-Wert und 
 * ein Hash-Wert �bergeben. Die Methoden passwortGen1 - 6 generieren alle m�glichen Zeichenkombinationen
 * (1-6 Zeichen). Am Anfang  jeden Strings  wird ein gegebener Salt-Wert drangeh�ngt, gehashed und mit dem  
 * beim Start �bergebenen Hash-Wert verglichen. Stimmen diese �berein, so hat man das Passwort 
 * zu dem (Salt+Hash) gefunden.
 */
public class Cracker {

	public boolean cracked = false;
	String newHash;

	String[] alpha = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s",
			"t", "u", "v", "w", "x", "y", "z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };

	private static String salt = "8kofferradio";
	private String c;

	static String h = "2b2935865b8a6749b0fd31697b467bd7";

	// Main-Methode
	public static void main(String[] args) {

		Cracker cs = new Cracker();

		cs.passwordGen1(salt, h);

	}

	// Hashfunktion MD5
	public String md5Hash(String message) {
		String md5 = "";
		if (null == message)
			return null;

		try {
			MessageDigest digest = MessageDigest.getInstance("MD5");
			digest.update(message.getBytes(), 0, message.length());
			md5 = String.format("%032x", new BigInteger(1, digest.digest()));

		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		return md5;

	}

	// Generiert alle 1-Stelligen Passw�rter
	public void passwordGen1(String s, String h) {

		do {

			for (int i = 0; i < alpha.length; i++) {

				c = alpha[i].toString();

				newHash = md5Hash(s + c);

				if (newHash.equals(h)) {
					cracked = true;
					System.out.println("Das Passwort lautet: " + c);
					System.out.println("Der Hash-Wert zum Passwort lautet: " + h);
					cracked = true;
					System.exit(0);
				} else if (newHash != h && c.equals("9")) {

					passworgGen2(s, h);
				}

			}
		} while (cracked);

	}

	// Generiert alle 2-Stelligen Passw�rter
	private void passworgGen2(String s, String h) {

		do {

			for (int i = 0; i < alpha.length; i++) {
				for (int j = 0; j < alpha.length; j++) {
					c = alpha[i].toString() + alpha[j].toString();

					newHash = md5Hash(s + c);
					if (newHash.equals(h)) {
						System.out.println("Das Passwort lautet: " + c);
						System.out.println("Der Hash-Wert zum Passwort lautet: " + h);
						cracked = true;
						System.exit(0);
					} else if (newHash != h && c.equals("99")) {

						passworgGen3(s, h);
					}

				}
			}
		} while (cracked);

	}

	// Generiert alle 3-Stelligen Passw�rter
	private void passworgGen3(String s, String h) {
		do {

			for (int i = 0; i < alpha.length; i++) {

				for (int j = 0; j < alpha.length; j++) {
					for (int k = 0; k < alpha.length; k++) {
						c = alpha[i].toString() + alpha[j].toString() + alpha[k].toString();

						newHash = md5Hash(s + c);
						if (newHash.equals(h)) {
							System.out.println("Das Passwort lautet: " + c);
							System.out.println("Der Hash-Wert zum Passwort lautet: " + h);
							cracked = true;
							System.exit(0);
						} else if (newHash != h && c.equals("999")) {

							passworgGen4(s, h);
						}

					}
				}
			}

		} while (cracked);

	}

	// Generiert alle 4-Stelligen Passw�rter
	private void passworgGen4(String s, String h) {
		do {

			for (int i = 0; i < alpha.length; i++) {

				for (int j = 0; j < alpha.length; j++) {
					for (int k = 0; k < alpha.length; k++) {
						for (int l = 0; l < alpha.length; l++) {
							c = alpha[i].toString() + alpha[j].toString() + alpha[k].toString() + alpha[l].toString();

							newHash = md5Hash(s + c);
							if (newHash.equals(h)) {
								System.out.println("Das Passwort lautet: " + c);
								System.out.println("Der Hash-Wert zum Passwort lautet: " + h);
								cracked = true;
								System.exit(0);
							} else if (newHash != h && c.equals("9999")) {

								passworgGen5(s, h);
							}

						}
					}
				}
			}
		} while (cracked);

	}

	// Generiert alle 5-Stelligen Passw�rter
	private void passworgGen5(String s, String h) {
		do {

			for (int i = 0; i < alpha.length; i++) {

				for (int j = 0; j < alpha.length; j++) {
					for (int k = 0; k < alpha.length; k++) {
						for (int l = 0; l < alpha.length; l++) {
							for (int m = 0; m < alpha.length; m++) {
								c = alpha[i].toString() + alpha[j].toString() + alpha[k].toString()
										+ alpha[l].toString() + alpha[m].toString();
								newHash = md5Hash(s + c);
								if (newHash.equals(h)) {
									System.out.println("Das Passwort lautet: " + c);
									System.out.println("Der Hash-Wert zum Passwort lautet: " + h);
									cracked = true;
									System.exit(0);
								} else if (newHash != h && c.equals("99999")) {

									passworgGen6(s, h);
								}

							}
						}
					}
				}
			}
		} while (cracked = false);

	}

	// Generiert alle 6-Stelligen Passw�rter
	private void passworgGen6(String s, String h) {
		do {

			for (int i = 0; i < alpha.length; i++) {

				for (int j = 0; j < alpha.length; j++) {
					for (int k = 0; k < alpha.length; k++) {
						for (int l = 0; l < alpha.length; l++) {
							for (int m = 0; m < alpha.length; m++) {
								for (int n = 0; n < alpha.length; n++) {
									c = alpha[i].toString() + alpha[j].toString() + alpha[k].toString()
											+ alpha[l].toString() + alpha[m].toString() + alpha[n].toString();
									newHash = md5Hash(s + c);
									if (newHash.equals(h)) {
										System.out.println("Das Passwort lautet: " + c);
										System.out.println("Der Hash-Wert zum Passwort lautet: " + h);
										cracked = true;
										System.exit(0);
									} else if (newHash != h && c.equals("99999")) {

										System.out.println("Das Passwort ist l�nger als 6 Zeichen oder enth�lt"
												+ "Sonderzeichen/Gro�buchstaben");
									}

								}
							}
						}
					}
				}
			}
		} while (cracked = false);

	}
}
